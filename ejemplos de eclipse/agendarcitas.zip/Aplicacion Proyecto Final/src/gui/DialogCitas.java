package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class DialogCitas extends JDialog  {

	
	
	Grafica grafica = new Grafica ();

	ArrayList<Persona> arrayList = new ArrayList<Persona>();
	
	private JLabel l1,l2,l3,l4,l5;
	private JTextField t1,t2,t3,t4;
	private JButton bagregar,bmostrar,b3,b4,bbuscar;
	private JComboBox combo1;
	private JTextArea a1;
	
	
	ArrayList<Citas> arraycitas = new ArrayList<Citas>();

 
	
	
	 public void iniciarcitas (){
	    	
	    	this.setTitle("Registro de Citas");
			this.setVisible(true);
			this.setSize(700, 450);
			this.setLocation(0,0);
			iniciar ();
	    	
	    }
	
	public void iniciar ()
	{
		
		setLayout (null);
		
		
        combo1 = new JComboBox ();
        combo1.setBounds(110, 95, 100, 20);
        combo1.addItem("ninguno");
        combo1.addItem("c.externa");
        combo1.addItem("pediatria");
        combo1.addItem("dermatologia");
        combo1.addItem("rayos x");
        combo1.addItem("odontologia");
        combo1.addItem("cirugia");
        combo1.addItem("ginecologia");
        combo1.addItem("psicologia");
        combo1.addItem("ortopedia");
        add(combo1);
		
		bagregar = new JButton ("insertar");
		bagregar.setBounds(10, 240, 100, 20);
		add(bagregar);
		
		bmostrar = new JButton ("Mostrar");
		bmostrar.setBounds(10, 270, 100, 20);
		add(bmostrar);
		
		b3 = new JButton ("limpiar");
		b3.setBounds(120, 270, 100, 20);
		add(b3);
		
		b4 = new JButton ("B.avanzada");
		b4.setBounds(10, 350, 100, 20);
		add(b4);
		
		
		
		bbuscar = new JButton ("Buscar ");
		bbuscar.setBounds(10, 310, 100, 20);
		add(bbuscar);
		
		t1 = new JTextField ();
		t1.setBounds(110, 10, 100, 20);
		add(t1);
		
		t2 = new JTextField ();
		t2.setBounds(110, 50, 100, 20);
		add(t2);
	
		t3 = new JTextField ();
		t3.setBounds(110, 155, 100, 20);
		add(t3);
		
		t4 = new JTextField ();
		t4.setBounds(110, 195, 100, 20);
		add(t4);
		
		
		a1 = new JTextArea ();
		a1.setBounds(220, 20, 420, 380);
		a1.setEditable(false);
		add(a1);
		
		
		
		l1 = new JLabel ("Documento");
		l1.setBounds(10, 0, 100, 50);
		add(l1);
		
		
		l2 = new JLabel ("tipo");
		l2.setBounds(5, 85, 100, 50);
		add(l2);
		
		
		l3 = new JLabel ("fecha");
		l3.setBounds(5, 135, 100, 50);
		add(l3);
		
		l4 = new JLabel ("lugar");
		l4.setBounds(10, 185, 100, 50);
		add(l4);
		
		l5 = new JLabel ("Nombre");
		l5.setBounds(10, 40, 100, 50);
		add(l5);
		
		
		eventos ();
		
	}
	
public void eventos (){
	
	
	
	
	
		
		bagregar.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
		
				
				String nombrepaciente,consulta,fecha,lugar,documento;
				
				nombrepaciente = t1.getText();
				consulta =  (String) combo1.getSelectedItem();
				fecha = t3.getText();
				lugar = t4.getText();
				documento = t2.getText();
				
				//Grafica grafica = new Grafica ();
				
				Citas cita = new Citas (nombrepaciente,consulta,fecha,lugar,documento);
				arraycitas.add(cita);
				
				t1.setText("");
				t2.setText("");
				t3.setText("");
				t4.setText("");
				combo1.setSelectedIndex(0);
				
				
				
				
				/*for (int i =0;i<grafica.arrayList.size();i++){
					
					
					if (documento.equals(grafica.arrayList.get(i).getDocumento())){
					
						Citas cita = new Citas (nombrepaciente,consulta,fecha,lugar,documento);
						arraycitas.add(cita);
						t1.setText("");
						t2.setText("");
						t3.setText("");
						t4.setText("");
						combo1.setSelectedIndex(0);
						
					}
					else
					{
						
					}
		
					
				}*/
				
				
			}
		});
		
		bmostrar.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				
				for (int i =0; i <arraycitas.size(); i ++){
					
					
					
					a1.append(arraycitas.get(i).getNombrepaciente() + "\t" + arraycitas.get(i).getDocumento() + "\t" +arraycitas.get(i).getConsulta() +
							"\t" + arraycitas.get(i).getFecha() + "\t" + arraycitas.get(i).getLugar()
							+ "\n");
					
				
				}
				
				
			}
		});
		b3.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				
				a1.setText("");
					
			
				
			}
		});
		
		
		bbuscar.addActionListener(new ActionListener() {
			
		
			public void actionPerformed(ActionEvent e) {
				
				
				buscarnombre();
			}
		});
		
		
		b4.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent arg0) {
				
				buscarid();
			}
		});
		
	}



             public void setText (String elTexto)
{
              t1.setText(elTexto);
}

             public void setText2 (String nombre){
            	 
            	 t2.setText(nombre);
             }
             



public void buscarnombre (){
			
			
			
			String x = (JOptionPane.showInputDialog("documento del paciente que desea buscar")); 
			
				
				
			for (int i =0; i<arraycitas.size(); i++){
				
			try {
				
				if (x.equals(arraycitas.get(i).getNombrepaciente())) {
					
					
					JOptionPane.showMessageDialog(null,arraycitas.get(i).getNombrepaciente() + "\n" +  arraycitas.get(i).getConsulta()
							+ "\n" + arraycitas.get(i).getFecha() + "\n" + arraycitas.get(i).getLugar());
					
					
				}
			}
			catch (Exception e ){
				
				JOptionPane.showMessageDialog(null, "No se Encontr� el nombre del paciente :" + x);
				
			}
		
	}
	
		}

public void buscarid (){
			
			
			
			String x = (JOptionPane.showInputDialog("nombre del paciente")); 
			
				
				
			for (int i =0; i<arraycitas.size(); i++){
				
			try {
				
				if (x.equals(arraycitas.get(i).getDocumento())) {
					
					
					JOptionPane.showMessageDialog(null,arraycitas.get(i).getNombrepaciente() + "\n" +  arraycitas.get(i).getConsulta()
							+ "\n" + arraycitas.get(i).getFecha() + "\n" + arraycitas.get(i).getLugar());
					
					
				}
			}
			catch (Exception e ){
				
				JOptionPane.showMessageDialog(null, "No se Encontr� el documento :" + x);
				
			}
		
	}
	
		}
		
}

