package gui;

import java.awt.Color;
import java.awt.List;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class ClasePrincipal {
	

	public static void main (String []args){
		
		DialogCitas cita = new DialogCitas ();

		
		Grafica gr = new Grafica ();
		gr.iniciar();
		gr.setForeground(Color.black);
	

	}
	
}
