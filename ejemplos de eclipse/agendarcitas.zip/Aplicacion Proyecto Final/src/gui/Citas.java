package gui;

public class Citas {

	private String nombrepaciente,consulta,fecha,lugar,documento;

	
	
	public Citas(String nombrepaciente, String consulta, String fecha,
			String lugar, String documento) {
		super();
		
		
		this.nombrepaciente = nombrepaciente;
		this.consulta = consulta;
		this.fecha = fecha;
		this.lugar = lugar;
		this.documento = documento;
	}


	
	public String getNombrepaciente() {
		return nombrepaciente;
	}

	public void setNombrepaciente(String nombrepaciente) {
		this.nombrepaciente = nombrepaciente;
	}

	public String getConsulta() {
		return consulta;
	}

	public void setConsulta(String consulta) {
		this.consulta = consulta;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public String getLugar() {
		return lugar;
	}

	public void setLugar(String lugar) {
		this.lugar = lugar;
	}



	public String getDocumento() {
		return documento;
	}



	public void setDocumento(String documento) {
		this.documento = documento;
	}
	
	
	
}
