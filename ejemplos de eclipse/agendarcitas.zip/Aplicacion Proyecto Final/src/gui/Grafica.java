package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Event;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.util.ArrayList;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.ScrollPaneConstants;
import javax.swing.table.DefaultTableModel;

public class Grafica extends JFrame implements MouseListener {

	private JButton bguardar,bmostrar,beliminar,bborrar,beditar,bcancelar;
	private JLabel l1,l2,l3,l4,l5,l6,l7;
	private JTextField t1,t2,t3,t4,t6,t7;
	private JTextArea a1;
	private JMenuBar barramenu;
	private JMenu menu,ayuda;
	private JMenuItem agregar,buscar,itemayuda,acerca,salir,npacientes,antecedentes,citas;
	private JComboBox combo1,combo2,combo3;
	private DefaultTableModel de_tabla ;
	private JScrollPane barra;
	private JTable tabla;
	
	
	ArrayList<Persona> arrayList = new ArrayList<Persona>();

	
	
	int posicion,estado;
	int contador=0 ;
	String documento;


	
	
	Persona per = new Persona ();
	
	 

	
	private final static String newline = "\t";

	//   se captura la fila y se cargan los valores a las cajas de texto
	
	public void ta (){
		
		//Grafica.this.arrayList.size();
		JOptionPane.showMessageDialog(null, Grafica.this.arrayList.size());
	}
	
	public void tam (){
		
		this.arrayList.size();
		JOptionPane.showMessageDialog(null,this.arrayList.size());

		
	}
	
	
	public void seleccionarRegistro (){
		
		
	String sexo;	
	String Tipo;	
	String sino;
	posicion = tabla.getSelectedRow();
	t1.setText(String.valueOf(tabla.getValueAt(posicion, 0)));
	t2.setText(String.valueOf(tabla.getValueAt(posicion, 1)));
	t3.setText(String.valueOf(tabla.getValueAt(posicion, 2)));
	t4.setText(String.valueOf(tabla.getValueAt(posicion, 4)));
	t6.setText(String.valueOf(tabla.getValueAt(posicion, 6)));
	t7.setText(String.valueOf(tabla.getValueAt(posicion, 8)));
	
	
	sexo = String.valueOf(tabla.getValueAt(posicion, 5));
	Tipo = String.valueOf(tabla.getValueAt(posicion, 3));
	sino = String.valueOf(tabla.getValueAt(posicion, 7));

	
	switch (sexo ){
	
	case "Masculino" :
	
		combo1.setSelectedIndex(1);
	
		break;
		
	case "Femenino" :
		
		combo1.setSelectedIndex(2);

		break;
	}
	
	
	switch (Tipo){
	
	case "C.C" :
		
		combo2.setSelectedIndex(1);
		break;
		
	case "T.I" : 
		
		combo2.setSelectedIndex(2);
		break;
		
	case "Extrangera" :
		
		 combo2.setSelectedIndex(3);

		 break;
	
	}
	
        switch (sino ){
	
	case "SI" :
	
		combo3.setSelectedIndex(1);
	
		break;
		
	case "NO" :
		
		combo3.setSelectedIndex(2);

		break;
	}
	

	
	}
	
	
		// limpia de la tabla desde el 1 hasta el ultimo
		
	public void limpiarregistro (){
		
		while (tabla.getRowCount() > 0){
			
			((DefaultTableModel)tabla.getModel()).removeRow(0);
			
			
		}
	}
	
	
	public void limpiarTextos (){
		
		t1.setText("");
		t2.setText("");
		t3.setText("");
		t4.setText("");
		t6.setText("");
		t7.setText("");
		
	}
	
	
	public void activarbotones (){
		
		bguardar.setEnabled(true);
		bmostrar.setEnabled(true);
		beliminar.setEnabled(true);
		bborrar.setEnabled(true);
	
		
		
	}
	
	public void activarTextos (){

		t1.setEditable(true);
		t2.setEditable(true);
		t3.setEditable(true);
		t4.setEditable(true);
		t6.setEditable(true);
		t7.setEditable(true);
		
	}
	
	public void desactivarTextos (){
		

		t1.setEditable(false);
		t2.setEditable(false);
		t3.setEditable(false);
		t4.setEditable(false);
		t6.setEditable(false);
		t7.setEditable(false);
		
	}
	
	
	public void buscarantecedentes (){
		
			String x = (JOptionPane.showInputDialog("ingrese antecedente a buscar")); 
			
				try {
				
			for (int i =0; i<arrayList.size(); i++){
				
				
			
				if (x.equals(arrayList.get(i).getAntecedentes())) {
					
					
					
					JOptionPane.showMessageDialog(null, 
					"los siguientes pacientes se encontraron con: " + "\t" + x + "\n" + "Nombre :" + arrayList.get(i).getNombre() 
					+ "\n" + "Apellido :" + arrayList.get(i).getApellido() + "\n" + "Documento :" + arrayList.get(i).getDocumento()
					+ "\n" + arrayList.get(i).getEdad());
				
				}
			         }
				}
				catch (Exception e){
					
					JOptionPane.showMessageDialog(null, "no se encontro nada");

				}
			}
		
		
	
	
	
	// se agregan los datos al arrayList
	
	public void agregar (){
	
		
		
		String apellido,documento,nombre,sexo,seguro;
		int edad;
        String antecedentes,id,sino;
		
		
	try {
		edad = Integer.parseInt(t4.getText());
	    sexo = (String) combo1.getSelectedItem();
        seguro = t6.getText();
        nombre = t1.getText();
        apellido = t2.getText();
        sino = (String) combo3.getSelectedItem();
        antecedentes = t7.getText();
        documento = t3.getText();
        id = (String) combo2.getSelectedItem();
		
		//Persona persona = new Persona (nombre,apellido,documento,edad,sexo,seguro,antecedentes);
	    Persona personas = new Persona ( nombre,apellido,documento,id,edad,sexo, seguro,sino,antecedentes);
		
		arrayList.add(personas);
		
		limpiarTextos ();
	    bmostrar.setEnabled(true);
	    combo1.setSelectedIndex(0);
		combo2.setSelectedIndex(0);
	    combo3.setSelectedIndex(0);
		desactivarbotones();
		desactivarTextos();
		limpiarregistro();
		
		
		
	}
	catch (NumberFormatException e){
		JOptionPane.showMessageDialog(null, "ingrese un valor numerico en la edad/documento");
	}
	
	}
	
	
	public void mostrar (){
		
		
		if (arrayList.size() > 0){
		
		try {
		
		
	        for ( int p =1; p <= arrayList.size(); p++){
			
			de_tabla.addRow(new Object [] {arrayList.get(p-1).getNombre(),arrayList.get(p-1).getApellido(),
					arrayList.get(p-1).getDocumento(),arrayList.get(p-1).getId(),arrayList.get(p-1).getEdad(),
					arrayList.get(p-1).getSexo(),arrayList.get(p-1).getSeguro(),
					arrayList.get(p-1).getSino(), arrayList.get(p-1).getAntecedentes()});
		}
		}
		catch (Exception e ){
			
			JOptionPane.showMessageDialog(null, "La posicion no se ha creado");
		}
	
	}
		else {
			
			JOptionPane.showMessageDialog(null, "No hay nada para mostrar");
			
		}
	}
	
	
	public void Eliminar (){
		
		
		if (arrayList.size() > 0 ){
		de_tabla.removeRow(posicion);
		arrayList.remove(posicion);
		limpiarTextos ();
		}
		
		else {
			
			JOptionPane.showMessageDialog(null, "No hay nada para Eliminar");
		}
	}
	
	
	public void guardar (){
		// se guarda el nuevo registro
	if (estado == 1){
		
		agregar();
		activarbotones ();
		
		
	}
	// se guarda el registro a editar
	
	
	
	else if ( estado ==2){
		
		
		try {
		de_tabla.removeRow(posicion);
		
		arrayList.remove(posicion);
		
		limpiarregistro();
		agregar();
		
		for (Persona x : arrayList){
			
		de_tabla.insertRow(posicion,new Object[] { x.getNombre(),x.getApellido(),x.getDocumento(),x.getId(),x.getEdad(),x.getSexo(),x.getSeguro()});
	
		cancelar();
		}
		
		}
		catch (Exception e ){
			
			JOptionPane.showMessageDialog(null, "se ha modificado ");
		}
		
		
	}
	
		
	}
	
	
	
	public void cancelar (){
		
		desactivarTextos();
		activarbotones();
		limpiarTextos();
		limpiarregistro();
		combo1.setSelectedIndex(0);
		combo2.setSelectedIndex(0);
		combo3.setSelectedIndex(0);
		t3.setEditable(false);
		
	}
		
		public void buscar (){
	
		if (arrayList.size() > 0 ){
	
			String x = (JOptionPane.showInputDialog("ingrese el numero de documento a mostrar")); 
			
				
				
			for (int i =0; i<arrayList.size(); i++){
				
				try {
			
				if (x.equals(arrayList.get(i).getDocumento())) {
					
					
					JOptionPane.showMessageDialog(null,"Nombre : " +  arrayList.get(i).getNombre() + "\n" + "Apellido :" + arrayList.get(i).getApellido() +
							"\n" + "Documento : " + arrayList.get(i).getDocumento() + "\n" + "Tipo :" + arrayList.get(i).getId() + "\n" + 
							"Edad :" + arrayList.get(i).getEdad() + "\n" + "Sexo :" + arrayList.get(i).getSexo() +
							"\n" + "Seguro : "  +  arrayList.get(i).getSeguro() + "\n" + "antecedente : " +
							arrayList.get(i).getAntecedentes());
				}
				
				}
				catch (Exception e){
					
					JOptionPane.showMessageDialog(null, "no se encontro nada");

				}
			}
		}
			}
	
	
	public void tamano (){
		JOptionPane.showMessageDialog(null, "Se han encontrado " + arrayList.size() + " Pacientes en el historial");
	}
	
	
	public void comprobardocumento (){
		
		 documento =JOptionPane.showInputDialog("Por favor digite el numero de documento al cual desea agendar una cita");
		
		for (int i =0; i<arrayList.size(); i ++ ){
			
			contador ++;
			
			try {
			if (documento.equals(arrayList.get(i).getDocumento())){
				
				DialogCitas cita = new DialogCitas ();

				cita.iniciarcitas();
				cita.setText(documento);
				cita.setText2(arrayList.get(i).getNombre());
						
			}
			}
			catch (Exception e ){
				
				JOptionPane.showMessageDialog(null, "no se encontro el documento " + documento);
			}
			
	
			
		}
				
	}

	public void desactivarbotones (){
		
		
		bguardar.setEnabled(true);
		bmostrar.setEnabled(false);
		beliminar.setEnabled(false);
		bborrar.setEnabled(false);
		
		
		beditar.setEnabled(false);
	}
	
	
	public void habilitar (){
		
		t1.requestFocus(true);
		t1.setEditable(true);
		t2.setEditable(true);
		t4.setEditable(true);
		t6.setEditable(true);
		bguardar.setEnabled(true);
		beliminar.setEnabled(false);
		bborrar.setEnabled(true);
		beditar.setEnabled(true);
		combo1.setEnabled(true);
		combo2.setEnabled(true);
		combo3.setEnabled(true);
	}
	
	
	public void iniciar (){
		
		
		this.setTitle("Aplicativo para Citas medicas V 2.0 ");
		this.setVisible(true);
		this.setSize(630, 500);
		this.setLocation(0,0);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	
		botones ();
		
	}
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	String contenido [] = {"Nombre","Apellido", "Documento","Tipo","Edad","Sexo","Seguro","S/N","Antecedentes"};
	
	
	
	public void botones (){
		
		setLayout (null);
		
		int y = 40;
		int x = 10;
		
		de_tabla = new DefaultTableModel(null,contenido);
		tabla = new JTable(de_tabla);
		tabla.addMouseListener(this);
		barra = new JScrollPane(tabla);
		barra.setBounds(10, 320, 590, 100);
		this.barra.setBackground(Color.blue);
		add(barra);
		
		
		
		t1 = new JTextField ();
		t1.setBounds(x * 9, y, 120, 20);
		t1.setEditable(false);
		t1.setForeground(Color.BLACK);
		add (t1);
		t1.addKeyListener(new KeyAdapter() {
			
			 public void keyTyped(KeyEvent e)
			 {
			 char caracter = e.getKeyChar();
			 // Verificar si la tecla pulsada no es un digito
			 if(((caracter < '@') ||      (caracter > '[')) &&   (caracter != KeyEvent.VK_BACK_SPACE))
			 {
			 e.consume(); // ignorar el evento de teclado
			 }
			 }
		      });
		
		
		t2 = new JTextField ();
		t2.setBounds(x * 9, y*2, 120, 20);
		t2.setEditable(false);
		t2.setForeground(Color.BLACK);
		add (t2);
		t2.addKeyListener(new KeyAdapter() {
			
			 public void keyTyped(KeyEvent e)
			 {
			 char caracter = e.getKeyChar();
			 // Verificar si la tecla pulsada no es un digito
			 if(((caracter < '@') ||      (caracter > '[')) &&   (caracter != KeyEvent.VK_BACK_SPACE))
			 {
			 e.consume(); // ignorar el evento de teclado
			 }
			 }
		      });
		
		t3 = new JTextField ();
		t3.setBounds(x * 22, y*3, 120, 20);
		t3.setEditable(false);
		t3.setForeground(Color.BLACK);
		add (t3);
		
		
		t4 = new JTextField ();
		t4.setBounds(x * 9, y*4, 120, 20);
		t4.setEditable(false);
		t4.setForeground(Color.BLACK);
		add (t4);
	
		t7 = new JTextField ();
		t7.setBounds(x * 26, y*7, 100, 20);
		t7.setEditable(false);
		t7.setForeground(Color.BLACK);
		add (t7);
		t7.addKeyListener(new KeyAdapter() {
			
			 public void keyTyped(KeyEvent e)
			 {
			 char caracter = e.getKeyChar();
			 // Verificar si la tecla pulsada no es un digito
			 if(((caracter < '@') ||      (caracter > '[')) &&   (caracter != KeyEvent.VK_BACK_SPACE))
			 {
			 e.consume(); // ignorar el evento de teclado
			 }
			 }
		      });
		t6 = new JTextField ();
		t6.setBounds(x * 9, y*6, 120, 20);
		t6.setEditable(false);
		t6.setForeground(Color.BLACK);
		add (t6);
		t6.addKeyListener(new KeyAdapter() {
			
			 public void keyTyped(KeyEvent e)
			 {
			 char caracter = e.getKeyChar();
			 // Verificar si la tecla pulsada no es un digito
			 if(((caracter < '@') ||      (caracter > '[')) &&   (caracter != KeyEvent.VK_BACK_SPACE))
			 {
			 e.consume(); // ignorar el evento de teclado
			 }
			 }
		      });
		
		l1 = new JLabel ("Nombre");
		l1.setBounds(x, y, 70, 10);
		l1.setFont(new Font("COMIC SANS MS", Font.BOLD,11));
		l1.setForeground(Color.BLUE);
		add (l1);
		
		l2 = new JLabel ("Apellido");
		l2.setBounds(x, y * 2, 70, 10);
		l2.setFont(new Font("COMIC SANS MS", Font.BOLD,11));
		l2.setForeground(Color.BLUE);
		add (l2);
		
		l3 = new JLabel ("Documento");
		l3.setBounds(x, y * 3, 70, 10);
		l3.setFont(new Font("COMIC SANS MS", Font.BOLD,11));
		l3.setForeground(Color.BLUE);
		add (l3);
		
		l4 = new JLabel ("Edad");
		l4.setBounds(x, y * 4 , 50, 10);
		l4.setFont(new Font("COMIC SANS MS", Font.BOLD,11));
		l4.setForeground(Color.BLUE);
		add (l4);
		
		l5 = new JLabel ("Sexo");
		l5.setBounds(x, y * 5, 50, 10);
		l5.setFont(new Font("COMIC SANS MS", Font.BOLD,11));
		l5.setForeground(Color.BLUE);
		add (l5);
		
		l6 = new JLabel ("Seguro");
		l6.setBounds(x, y * 6, 70, 10);
		l6.setForeground(Color.BLUE);
		l6.setFont(new Font("COMIC SANS MS", Font.BOLD,11));

		add (l6);
		
		l7 = new JLabel ("Antecedentes clinicos");
		l7.setBounds(x, y * 7, 130, 10);
		l7.setForeground(Color.BLUE);
		l7.setFont(new Font("COMIC SANS MS", Font.BOLD,11));

		add (l7);
		
	
		
		bguardar = new JButton ("Guardar");
		bguardar.setBounds(380, 280, 100, 20);
		bguardar.setEnabled(false);
		add(bguardar);
		
		bmostrar = new JButton ("MOSTRAR");
		bmostrar.setBounds(380, 240, 100, 20);
		bmostrar.setEnabled(false);
		add(bmostrar);
		
		beliminar = new JButton ("Eliminar");
		beliminar.setBounds(380, 180, 100, 20);
		beliminar.setEnabled(false);
		add(beliminar);
		
		bborrar = new JButton ("borrar");
		bborrar.setBounds(380, 160, 100, 20);
		add(bborrar);
		bborrar.setEnabled(false);
	
		beditar = new JButton ("Editar");
		beditar.setBounds(380, 100, 100, 20);
		beditar.setEnabled(false);
		add(beditar);
		
		bcancelar = new JButton ("Cancelar");
		bcancelar.setBounds(380, 80, 100, 20);
		bcancelar.setEnabled(false);
		add(bcancelar);
		
		combo1 = new JComboBox ();
		combo1.setBounds(x * 9, y*5, 120, 20);
		combo1.addItem("Niguno");
		combo1.addItem("Masculino"); 
		combo1.addItem("Femenino");
		combo1.setEnabled(false);
		combo1.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				
				
				t6.requestFocus();
				
			}
		});
		add(combo1);
		
		combo2 = new JComboBox ();
		combo2.setBounds(x * 9, y*3, 120, 20);
		combo2.addItem("Niguno");
		combo2.addItem("C.C");
		combo2.addItem("T.I");
		combo2.addItem("Extrangera");
		combo2.setEnabled(false);
		combo2.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
			
				t3.setEditable(true);
				t3.requestFocus();
				
			}
		});
		add(combo2);
		
		combo3 = new JComboBox ();
		combo3.setBounds(x * 13, y*7, 120, 20);
		combo3.addItem("NINGUNO");
		combo3.addItem("SI");
		combo3.addItem("NO");
		combo3.setEnabled(false);
		add(combo3);
		
		combo3.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				
				if ( combo3.getSelectedIndex() == 1)
				{
					
					t7.setEditable(true);	
					t7.requestFocus();
				}
				
				
				
			
				
			}
		});
		
		
		barramenu = new JMenuBar ();
		
		menu = new JMenu ("Menu");
		ayuda = new JMenu ("Ayuda");
		
		agregar = new JMenuItem ("Nuevo");
		agregar.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N,ActionEvent.CTRL_MASK));

		
		buscar = new JMenuItem ("Buscar");
		buscar.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_B,ActionEvent.CTRL_MASK));
		
		salir = new JMenuItem ("Salir");
		salir.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F4,ActionEvent.ALT_MASK));

		citas = new JMenuItem ("Citas");
		citas.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C,ActionEvent.CTRL_MASK));
		
		npacientes = new JMenuItem ("N� pacientes");
		itemayuda = new JMenuItem ("Ayuda");
		acerca = new JMenuItem ( "Acerca de");
		antecedentes = new JMenuItem ("buscar antecendetes");
		this.barramenu.add(menu);
		this.barramenu.add(ayuda);
		
		this.ayuda.add(itemayuda);
		itemayuda.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "ayuda");
				
			}
		});
		
		
		this.ayuda.add(acerca);
		acerca.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				
				
				JOptionPane.showMessageDialog(null, "aplicacion creada originalmente por Luis Fernando Rodriguez Leon " + "\n" + 
				"basada en metodos, encapsulamiento,Clases y uso de los arrays");
				
			}
		});
		this.agregar.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent arg0) {
				habilitar ();
				desactivarbotones ();
				estado = 1;
				
				if (arrayList.size()== 0){
					JOptionPane.showMessageDialog(null, "Por favor diligenciar el formulario en Mayusculas");

				}
				
			}
		});
	
		
		this.buscar.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				
				buscar();
			}
		});
		
		this.antecedentes.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				
				
				buscarantecedentes ();
				
			}
		});
		
		this.salir.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
				
			}
		});
		
		this.npacientes.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				
				if (arrayList.size() > 0){
					tamano();
					}
					else {
						
						JOptionPane.showMessageDialog(null, "no hay pacientes en el historial");
					}
			}
		});
		
		this.antecedentes.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				
				
				
			}
		});
		this.citas.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				
				comprobardocumento();
				
			}
		});
		
		this.menu.add(agregar);
		this.menu.add(buscar);
		this.menu.add(npacientes);
		this.menu.add(antecedentes);
		this.menu.add(citas);
		this.menu.add(salir);
		
		
		
		this.setJMenuBar(this.barramenu);
		this.setLocationRelativeTo(null);
	
		JScrollPane deslisar = new JScrollPane (a1);
		add(deslisar,BorderLayout.CENTER);

		
		
		
		
		bguardar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
			
					guardar ();
					
				
			}
		});
		
		
		
		beliminar.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				
				Eliminar();
			}
		});
	
		
	
		bborrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				limpiarregistro();
			}
		});
	
	
		bmostrar.addActionListener(new ActionListener() {	
			public void actionPerformed(ActionEvent e) {	
				mostrar ();
			}
		});
		
		beditar.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				
				if ( e.getSource() == beditar){

					estado = 2;
					activarTextos();
					t1.requestFocus();
				}
			}
		});
		bcancelar.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				
				cancelar ();
				
			}
		});
	}


	public void mouseClicked(MouseEvent e) {
		if (e.getSource() == tabla){
			
			seleccionarRegistro();
			desactivarTextos ();
			beditar.setEnabled(true);
			bcancelar.setEnabled(true);
			bborrar.setEnabled(false);

		}
		
	}

	
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}
