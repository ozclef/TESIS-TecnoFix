package gui;

public class Persona {

	

	private String nombre;
	private String apellido;
	private String documento;
	private String id;
	private int edad;
	private String sexo;
	private String seguro;
	private String antecedentes;
	private String sino;
	
	public Persona (String documento){
		
		this.documento = documento;
		
	}
	
	public Persona(String nombre, String apellido, String documento) {
		
		this.nombre = nombre;
		this.apellido = apellido;
		this.documento = documento;
		
	}
	public Persona(String nombre, String apellido, String documento,String id, int edad,
			String sexo, String seguro) {
		
		
		this.nombre = nombre;
		this.apellido = apellido;
		this.documento = documento;
		this.edad = edad;
		this.sexo = sexo;
		this.seguro = seguro;
		this.id = id;
	}
	
	public Persona(String nombre, String apellido, String documento,String id, int edad,
			String sexo, String seguro,String sino,String antecedentes) {
		
		
		this.nombre = nombre;
		this.apellido = apellido;
		this.documento = documento;
		this.edad = edad;
		this.sexo = sexo;
		this.seguro = seguro;
		this.antecedentes = antecedentes;
		this.id = id;
		this.sino = sino;
	}
	

	public Persona (){
		this.nombre = "";
		this.apellido = "";
		this.documento = "";
		this.edad = 0;
		this.sexo = "";
		this.seguro = "";
	}
	
	
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellido() {
		return apellido;
	}
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	public String getDocumento() {
		return documento;
	}
	public void setDocumento(String documento) {
		this.documento = documento;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	public String getSeguro() {
		return seguro;
	}

	public void setSeguro(String seguro) {
		this.seguro = seguro;
	}

	public String getAntecedentes() {
		return antecedentes;
	}

	public void setAntecedentes(String antecedentes) {
		this.antecedentes = antecedentes;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSino() {
		return sino;
	}

	public void setSino(String sino) {
		this.sino = sino;
	}
	
}
